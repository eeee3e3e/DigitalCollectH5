<template>
  <div id="app">
    <base-router-view/>
  </div>
</template>

<script>
import { BaseRouterView } from '@/components'

export default {
  components: {
    BaseRouterView
  }
}
</script>

<style lang="less">
#app {
  height: 100%;
}
</style>
