<template>
  <div class="app-home-header">
    <img src="/static/images/home/background.png" alt="">
  </div>
</template>

<script>
export default {}
</script>

<style scoped lang="less">
.app-home-header {
  height: 120px;

  img {
    width: 100%;
  }
}
</style>
