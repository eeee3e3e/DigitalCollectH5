<template>
  <div class="app-help-document">
    <base-image src="/static/images/help.png"/>
  </div>
</template>

<script>
import { Image } from 'vant'

export default {
  components: {
    BaseImage: Image
  }
}
</script>

<style scoped>

</style>
