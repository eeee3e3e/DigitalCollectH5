const APP_SETTING = {

  // 页面title
  title: '城市数藏',

}

export default APP_SETTING
